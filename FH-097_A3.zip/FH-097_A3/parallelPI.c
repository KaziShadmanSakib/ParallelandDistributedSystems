/**********************************************************************
 * FILE: parallelPI.c
 * DESCRIPTION:  
 *   MPI pi Calculation Example - C Version 
 *   Point-to-Point communications example
 *   This program calculates pi using a "dartboard" algorithm.  See
 *   Fox et al.(1988) Solving Problems on Concurrent Processors, vol.1
 *   page 207.  All processes contribute to the calculation, with the
 *   master averaging the values for pi. This version uses low level 
 *   sends and receives to collect results.
 * AUTHOR: Blaise Barney. Adapted from Ros Leibensperger, Cornell Theory
 *   Center. Converted to MPI: George L. Gusciora, MHPCC (1/95) 
 * LAST REVISED: 10/05/23 Kazi Shadman Sakib
**********************************************************************/
#include "mpi.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


void srandom (unsigned seed);
double dboard (int darts);
#define ROUNDS 100      /* number of times "darts" is iterated */
#define MASTER 0        /* task ID of master task */

int main (int argc, char *argv[]){
   double	homepi,         /* value of pi calculated by current task */
   	pi,             /* average of pi after "darts" is thrown */
   	avepi,          /* average pi value for all iterations */
   	pirecv,         /* pi received from worker */
   	pisum;          /* sum of workers pi values */
   int	taskid,         /* task ID - also used as seed number */
   	numtasks,       /* number of tasks */
   	source,         /* source of incoming message */ 
   	mtype,          /* message type */
   	rc,             /* return code */
   	i, n;
   MPI_Status status;

   /* Initialize start time, end time and cpu time used */
   clock_t start_time, end_time;
   double cpu_time_used;

   /* Number of darts to throw for each round */
   int darts = 5000000;

   // Open the output file in append mode
   FILE *output_file = fopen("output.txt", "a");
   if (output_file == NULL) {
      fprintf(stderr, "Could not open the output file.\n");
      exit(EXIT_FAILURE);
   }

   /* Record the start time */
   start_time = clock();

   /* Obtain number of tasks and task ID */
   MPI_Init(&argc,&argv);
   MPI_Comm_size(MPI_COMM_WORLD,&numtasks);
   MPI_Comm_rank(MPI_COMM_WORLD,&taskid);

   /* Set seed for random number generator equal to task ID */
   srandom (taskid);

   avepi = 0;

   /*To distribute the workload evenly among the worker processes*/
   darts = (darts/(numtasks-1));

   for (i = 0; i < ROUNDS; i++) {
      /* All tasks calculate pi using dartboard algorithm */
      homepi = dboard(darts);

      /* Workers send homepi to master */
      /* - Message type will be set to the iteration count */
      if (taskid != MASTER) {
         mtype = i;
         rc = MPI_Send(&homepi, 1, MPI_DOUBLE,
                       MASTER, mtype, MPI_COMM_WORLD);
         } 
      else
         {
         /* Master receives messages from all workers */
         /* - Message type will be set to the iteration count */
         /* - Message source will be set to the wildcard DONTCARE: */
         /*   a message can be received from any task, as long as the */
         /*   message types match */
         /* - The return code will be checked, and a message displayed */
         /*   if a problem occurred */
         mtype = i;
         pisum = 0;
         for (n = 1; n < numtasks; n++) {
            rc = MPI_Recv(&pirecv, 1, MPI_DOUBLE, MPI_ANY_SOURCE,
                           mtype, MPI_COMM_WORLD, &status);
            /* keep running total of pi */
            pisum = pisum + pirecv;
            }
         /* Master calculates the average value of pi for this iteration */
         pi = (pisum + homepi)/numtasks;
         /* Master calculates the average value of pi over all iterations */
         avepi = ((avepi * i) + pi)/(i + 1); 
         printf("   After %8d throws, average value of pi = %10.8f\n",
                  (darts * (i + 1)),avepi);
         }    
      } 

   if (taskid == MASTER){
      /* Record the end time */
      end_time = clock();

      /* Calculating the CPU time needed to calculate PI */
      cpu_time_used = ((double) (end_time - start_time)) / CLOCKS_PER_SEC;
      printf("\nTime taken to calculate pi: %lf seconds\n", cpu_time_used);

      // Save cpu_time_used to the output file
      fprintf(output_file, "%lf\n", cpu_time_used);
      
      // Close the output file
      fclose(output_file);


      printf ("Real value of PI: %10.8f \n\n", avepi);
   }

   MPI_Finalize();
   return 0;
}


/**************************************************************************
* subroutine dboard
* DESCRIPTION:
*   Used in pi calculation example codes. 
*   See mpi_pi_send.c and mpi_pi_reduce.c  
*   Throw darts at board.  Done by generating random numbers 
*   between 0 and 1 and converting them to values for x and y 
*   coordinates and then testing to see if they "land" in 
*   the circle."  If so, score is incremented.  After throwing the 
*   specified number of darts, pi is calculated.  The computed value 
*   of pi is returned as the value of this function, dboard. 
*
*   Explanation of constants and variables used in this function:
*   darts       = number of throws at dartboard
*   score       = number of darts that hit circle
*   n           = index variable
*   r           = random number scaled between 0 and 1
*   x_coord     = x coordinate, between -1 and 1
*   x_sqr       = square of x coordinate
*   y_coord     = y coordinate, between -1 and 1
*   y_sqr       = square of y coordinate
*   pi          = computed value of pi
****************************************************************************/

double dboard(int darts){
   #define sqr(x)	((x)*(x))
   long random(void);
   double x_coord, y_coord, pi, r; 
   int score, n;
   unsigned int cconst;  /* must be 4-bytes in size */
   /*************************************************************************
    * The cconst variable must be 4 bytes. We check this and bail if it is
    * not the right size
    ************************************************************************/
   if (sizeof(cconst) != 4) {
      printf("Wrong data size for cconst variable in dboard routine!\n");
      printf("See comments in source file. Quitting.\n");
      exit(1);
      }
      /* 2 bit shifted to MAX_RAND later used to scale random number between 0 and 1 */
      cconst = 2 << (31 - 1);
      score = 0;

      /* "throw darts at board" */
      for (n = 1; n <= darts; n++)  {
         /* generate random numbers for x and y coordinates */
         r = (double)random()/cconst;
         x_coord = (2.0 * r) - 1.0;
         r = (double)random()/cconst;
         y_coord = (2.0 * r) - 1.0;

         /* if dart lands in circle, increment score */
         if ((sqr(x_coord) + sqr(y_coord)) <= 1.0)
              score++;
         }

   /* calculate pi */
   pi = 4.0 * (double)score/(double)darts;
   return(pi);
} 


