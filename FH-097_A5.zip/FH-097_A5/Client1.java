import java.rmi.*;
import java.util.Scanner; 
public class Client1 {

    public static void main(String[] args)
    {
        try
        {
            CipherServerInterface server = (CipherServerInterface) Naming.lookup("rmi://localhost:5001/server");
            System.out.println("Give a key (int) for Casar");
            Scanner scanner = new Scanner(System.in);

            int key = scanner.nextInt();
            String originalText = server.Caesar_cipher(key);
            System.out.println("Here is the original text");
            System.out.println(originalText);
            scanner.close();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
    
}


