import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.rmi.*;
import java.rmi.server.*;

public class CipherServer extends UnicastRemoteObject implements CipherServerInterface{
    private List<String> alphabets = new ArrayList<String>();
    String cipherText = new String();
    CipherServer() throws IOException,RemoteException
    {
        super();
        File file = new File("TabulaRecta.txt");
        Scanner scanner = new Scanner(file);
        while (scanner.hasNextLine()) {
            alphabets.add(scanner.nextLine());
        }
        scanner.close();
        file = new File("Cipher.txt");
        scanner = new Scanner(file);
        this.cipherText = scanner.nextLine();
        scanner.close();
    }
    public String vigenerCipher(String key)
    {
        
        String result = "";
        int i;
        int keyLen = key.length();
        for(i = 0; i < this.cipherText.length(); i++)
        {
            char ch = this.cipherText.charAt(i);
            char keyCh = key.charAt(i % keyLen);
            int k = (int)keyCh - (int)('A');
            
            char changedCh = this.Caesar_cipher(ch, k); 
            result += changedCh;
        }
        return result;
    }
    private char Caesar_cipher(char ciperChar, int key)
    {
        String selectedAlphabets = alphabets.get(key);
        int currIndex = selectedAlphabets.indexOf(ciperChar);
        char changedCh = alphabets.get(0).charAt(currIndex);
        return changedCh;

    }
    public String Caesar_cipher( int key)
    {
        String selectedAlphabets = alphabets.get(key);
        String result = new String();
        int i;
        for (i = 0 ; i < this.cipherText.length(); i++)
        {
            char ch = this.cipherText.charAt(i);
            int currIndex = selectedAlphabets.indexOf(ch);
            char changedCh = alphabets.get(0).charAt(currIndex);
            result += changedCh;
        }
        return result;
    }
    
}