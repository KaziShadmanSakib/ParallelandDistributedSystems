import java.rmi.*;
public interface CipherServerInterface extends  Remote{

    public String Caesar_cipher(int key) throws RemoteException;
    public String vigenerCipher(String key) throws RemoteException;

}
