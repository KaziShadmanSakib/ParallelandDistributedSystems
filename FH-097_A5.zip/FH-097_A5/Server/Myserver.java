import java.rmi.*;  
import java.rmi.registry.*;  
public class Myserver {
    public static void main(String[] args) 
    {
        System.out.println("Server has started");
        try
        {
            CipherServerInterface server = new CipherServer();
            Naming.rebind("rmi://localhost:5001/server", server);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }

    }
    
}
